
package feereport;
import java.sql.*;

public class AccountantDao {
	public static Connection getCon(){
		Connection con=null;
		try{
	
                    Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/accounting","root","");

		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static boolean validate(String name,String password){
		boolean status=false;
		try{
			Connection con=getCon();
			PreparedStatement ps=con.prepareStatement("select * from accountantlogin where uname=? and pass=?");
			ps.setString(1,name);
			ps.setString(2,password);
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			con.close();
		}catch(Exception e){System.out.println(e);}
		
		
		return status;
	}

	public static int save(Student s){
		int status=0;
		try{
			Connection con=AccountantDao.getCon();
			PreparedStatement ps=con.prepareStatement("insert into students values(?,?,?,?,?,?,?,?,?,?,?,?)");
                        ps.setInt(1,s.getRollno());
			ps.setString(2,s.getName());
			ps.setString(3,s.getEmail());
			ps.setString(4, s.getCourse());
			ps.setInt(5,s.getFee());
			ps.setInt(6,s.getPaid());
			ps.setInt(7,s.getDue());
			ps.setString(8,s.getAddress());
			ps.setString(9,s.getCity());
			ps.setString(10,s.getState());
			ps.setString(11,s.getCountry());
			ps.setString(12,s.getContactno());
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
        public static int edit(Student s){
		int status=0;
		try{
			Connection con=AccountantDao.getCon();
			PreparedStatement ps=con.prepareStatement("update students set name=?,email=?,course=?,"
                                + "fee=?,paid=?,due=?,address=?,city=?,state=?,country=?"
                                + ",contact=? where RollNo=?");
                      
			ps.setString(1,s.getName());
			ps.setString(2,s.getEmail());
			ps.setString(3, s.getCourse());
			ps.setInt(4,s.getFee());
			ps.setInt(5,s.getPaid());
			ps.setInt(6,s.getDue());
			ps.setString(7,s.getAddress());
			ps.setString(8,s.getCity());
			ps.setString(9,s.getState());
			ps.setString(10,s.getCountry());
			ps.setString(11,s.getContactno());
                        ps.setInt(12,s.getRollno());
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
        public static Student view(int roll){
            Student s=null;
            try{
            Connection con=AccountantDao.getCon();
            PreparedStatement st=con.prepareStatement("select * from students where RollNo=?");
            st.setInt(1,roll);
            ResultSet rs=st.executeQuery();
            while(rs.next()){
                 roll=rs.getInt(1);
                 String name=rs.getString(2);
                 String email=rs.getString(3);
                 String course=rs.getString(4);
                 String add=rs.getString(8);
                 String city=rs.getString(9);
                 String state=rs.getString(10);
                 String country=rs.getString(11);
                 String contact=rs.getString(12);
                 int fee=rs.getInt(5);
                 int paid=rs.getInt(6);
                 int due =rs.getInt(7);
                 s=new Student(roll,name,email,course,fee,paid,due,add,city,state,country,contact);
            }
            
        }catch(Exception e){System.out.println(e);}
            return s;
        }
}
