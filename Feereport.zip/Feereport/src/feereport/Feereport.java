
package feereport;

public class Feereport {

    public static void main(String[] args) {
        First first = new First();
    }
    
}
