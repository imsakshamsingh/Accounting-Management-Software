
package feereport;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class StudentDao {
    public static Connection getCon(){
		Connection con=null;
		try{
		            System.out.println("HI");
	
                    Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/accounting","root","");
                        		            System.out.println("HI");

		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static boolean validate(String name,String password){
		boolean status=false;
		try{
			Connection con=getCon();
			PreparedStatement ps=con.prepareStatement("select * from studentlogin where uname=? and pass=?");
			ps.setString(1,name);
			ps.setString(2,password);
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			con.close();
		}catch(Exception e){System.out.println(e);}
		
		
		return status;
	}
	public static int signup(String name,String password){
            int status=0;
            try{
			Connection con=getCon();
			PreparedStatement ps=con.prepareStatement("insert into studentlogin values(?,?)");
			ps.setString(1,name);
			ps.setString(2,password);
			status=ps.executeUpdate();
                        
                        System.out.println("HI");
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
        }
	
}
